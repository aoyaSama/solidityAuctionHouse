# solidityAuctionHouse
Starter code for Solidity programming assignment

Class assignment to study Bitcoin mining strategies in a simple simulator.


## Author
Auction.sol, DutchAuction.sol, EnglishAuction.sol, and VickreyAuction.sol by Takemitsu Yamanaka #757038

Code forked from @jcb82

This assignment was originally developed by Joseph Bonneau and Benedikt Bünz at Stanford, with later development by Joseph Bonneau, Assimakis Kattis and Kevin Choi at NYU.